
package com.mycompany.myshop.servlets;

import com.mycompany.myshop.Dao.UserDao;
import com.mycompany.myshop.entities.User;
import com.mycompany.myshop.helper.FactoryProvider;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            //coding
            
           String email=  request.getParameter("email");
            String password = request.getParameter("password");
           
            
            //validations
            //  authenticate user
            UserDao userDao = new UserDao(FactoryProvider.getFactory());
            User user = userDao.getUserByEmailAndPassword(email, password);
           // System.out.println(user);
           if(user==null)
           {
               out.println("<h1>Invalid Details</h1>");
               HttpSession httpSession=request.getSession();
               httpSession.setAttribute("message","Invalid Detalis !!");
               response.sendRedirect("login.jsp");
               return;
               
           }
           else
           {
               out.println("<h1>Welcome" +user.getUserName()+"</h1>");
               
               
               //login
               HttpSession httpSession=request.getSession();
               
              httpSession.setAttribute("current-user",user);
               
               switch (user.getUserType()) {
                   case "admin":
                       response.sendRedirect("admin.jsp");
                       break;
                   case "normal":
                       response.sendRedirect("normal.jsp");
                       break;
                   default:
                       out.println("Not identified");
                       //admin.jsp
                       
                       //normal.jsp
                       break;
               }
               
               
           }
            
                  
          
        }
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
